//formula to convert fahrenheit to celsius is °C = 5/9 * (°F - 32)

//function that will take input values and convert CtoF/FtoC
function computeTemp() {
	//get the current value of the text input 
	var temp = document.getElementById('temp').value;
	//variables to hold radio button values >> checked or not
	var x = document.getElementById("celsiusConverter").checked;
	var y = document.getElementById("fahrenheitConverter").checked;
	//variable to hold temperature value as its being calculated
	var computed;

	//checks if either text input is empty or not a number and check that one of the radio inputs is selected. Prompts the use if otherwise.
    if ((isNaN(temp) || (temp == "")) || ((x !== true) && (y !== true))) {
        if ((x !== true) && (y !== true)) {
            document.getElementById("answer").innerHTML = "Please select a conversion!";
        }
        if (isNaN(temp) || (temp == "")) {
            document.getElementById("answer").innerHTML = "Please enter a number in the input field!";
        }
	//if input is valid, determines which conversion the user wants
    } else {
		//checks if CtoF radio input is selected
		//converts value and "rounds" to one decimal place
        if (x == true) {
    		computed = (temp * (9/5)) + 32;
			computed = computed.toFixed(1);
			computed = temp + " &deg;C is " + computed + " &deg;F."
		//if FtoC radio input is selected
		//converts value and "rounds" to one decimal place
    	} else {
    			computed = (temp - 32) * (5/9);
				computed = computed.toFixed(1);
				computed = temp + " &deg;F is " + computed + " &deg;C."
    			}
		//outputs converted value and message to the screen
    	document.getElementById("answer").innerHTML = computed;
    	}
    }

//resets form values and fields when "reset" button is clicked
function resetTemp() {
	document.getElementById("temp").value = "";
    document.getElementById("celsiusConverter").checked = false;
	document.getElementById("fahrenheitConverter").checked = false;
	document.getElementById("answer").innerHTML = "";
}

